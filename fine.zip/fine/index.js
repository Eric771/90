const { Client } = require('discord.js-selfbot-v13');
const { joinVoiceChannel } = require("@discordjs/voice");

const client = new Client({ checkUpdate: true });
const config = require(`${process.cwd()}/config.json`);

client.on('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);

    await joinVC(client);
});

client.on('voiceStateUpdate', async (oldState, newState) => {
    try {
        if (newState.channel.id === `1201154697344585739`) { // if its the channel
            if (newState.channel.members.size > 99) return;
            setInterval(async () => {
                const guild = client.guilds.cache.get(`1202220495856996364`);
                const voiceChannel = guild.channels.cache.get(`1204001646879969320`);
                const connection = joinVoiceChannel({
                channelId: voiceChannel.id,
                guildId: guild.id,
                adapterCreator: guild.voiceAdapterCreator,
                selfDeaf: false,
                selfMute: false
            }, 360 * 1000);
        });
    }
}
catch {
}
});
client.on('voiceStateUpdate', async (oldState, newState) => {
    try {
        if (newState.channel.id === `1204001646879969320`) { // if its the channel
            if (newState.channel.members.size > 99) return;
            setInterval(async () => {
                const guild = client.guilds.cache.get(`1202220495856996364`);
                const voiceChannel = guild.channels.cache.get(`1203638570724884543`);
                const connection = joinVoiceChannel({
                channelId: voiceChannel.id,
                guildId: guild.id,
                adapterCreator: guild.voiceAdapterCreator,
                selfDeaf: false,
                selfMute: false
            }, 540 * 1000);
        });
    }
}
catch {
}
});

client.on('message', message => {
    if (message.content === "$")
    if (message.channel.id === '1201155513954615316')
    if (message.author.id === '1076128293721489418') { 
      const interval = setInterval (function () {
      message.channel.send(`test connection  ${Math.round(client.ws.ping)}ms`);
    }, 600 * 1000); 
    }
  });
client.login(config.token);
async function joinVC(client) {
    const guild = client.guilds.cache.get(`1202220495856996364`);
    const voiceChannel = guild.channels.cache.get(`1201154697344585739`);
    const connection = joinVoiceChannel({
        channelId: voiceChannel.id,
        guildId: guild.id,
        adapterCreator: guild.voiceAdapterCreator,
        selfDeaf: false,
        selfMute: true
    });
}